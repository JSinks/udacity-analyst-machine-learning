Here are my responses to the free response questions.

# 1. Summarize for us the goal of this project and how machine learning is useful in trying to accomplish it. As part of your answer, give some background on the dataset and how it can be used to answer the project question. Were there any outliers in the data when you got it, and how did you handle those?  [relevant rubric items: “data exploration”, “outlier investigation”]

The goal of this project is to analyse email and financial data from the Enron scandal to attempt to classify persons as either "people of interest" (party to the fraud) or not. The data set is highly diverse, but the training data is relatively small (only 146 people) which could cause problems in a train/test split. In addition there are not many "true" signals - only 18 of the 146 records are POI's, so this will not give us a lot to train from. There are plenty of features available (21), but every feature has at least 1 user who is missing data (shown as NaN) and there are a couple of outliers that should be removed to help performance. 

Looking at a simple plot we can find our first outlier (TOTAL), digging through the names I also noted there was a bad pine of data "THE TRAVEL AGENCY IN THE PARK" that is likely not a POI (as it's a business) so can be removed. Finally there was one user who had no data in his record (EUGENE), so can be removed as he has nothing to add to the picture and will not be able to be accurately classified.

# 2. What features did you end up using in your POI identifier, and what selection process did you use to pick them?  Did you have to do any scaling? Why or why not? As part of the assignment, you should attempt to engineer your own feature that does not come ready-made in the dataset -- explain what feature you tried to make, and the rationale behind it. (You do not necessarily have to use it in the final analysis, only engineer and test it.) In your feature selection step, if you used an algorithm like a decision tree, please also give the feature importances of the features that you use, and if you used an automated feature selection function like SelectKBest, please report the feature scores and reasons for your choice of parameter values.  [relevant rubric items: “create new features”, “intelligently select features”, “properly scale features”]

I used a SelectKBest algorithm to reduce the available feature set to the best 8-10 features (automatically determined to be 9 via a GridSearch). The specific features that won were: 'salary', 'bonus', 'deferred_income', 'exercised_stock_options', 'shared_receipt_with_poi', 'total_payments', 'total_stock_value', 'to_poi_pct', and 'shared_receipt_with_poi'. This was then reduced further to 2-4 primary components by PCA with the aim of making my classifier more accurate (Decision Tree, chosen by GridSearch - tuned for maximum F1 performance). Based on the classifier types, scaling was not relevant for my model (as the GridSearch had to choose from classifiers that do not benefit from scaled data). 

I built 2 new features - what % of total messages were to/from people of interest, thinking that this may be more useful than an absolute number. However neither of these features were selected by the KBest algorithm so are not included in the final analysis.

# 3. What algorithm did you end up using? What other one(s) did you try? How did model performance differ between algorithms?  [relevant rubric item: “pick an algorithm”]

GridSearch selected the best algorithm and configuration - in final it appears a Decisiontree was best for maximising f1 (chosen as we were trying to boost recall + precision, which f1 is a proxy for). In individual runs of other models (Random Forest, Gaussian, etc) all had higher accuracy but suffered significant problems with recall (most being under 0.2 regardless of parameters tuned).

# 4. What does it mean to tune the parameters of an algorithm, and what can happen if you don’t do this well?  How did you tune the parameters of your particular algorithm? What parameters did you tune? (Some algorithms do not have parameters that you need to tune -- if this is the case for the one you picked, identify and briefly explain how you would have done it for the model that was not your final choice or a different model that does utilize parameter tuning, e.g. a decision tree classifier).  [relevant rubric items: “discuss parameter tuning”, “tune the algorithm”]

Tuning refers to changing parameters of the selected algorithm to adjust how the model works and interacts with the provided data. If you do it wrong, you can end up negatively impacting the performance of your model. I tuned using GridSearch and a parameter dictionary, to automatically adjust and find the best combination of features that maximised for f1 (a proxy for recall + precision scores that we were aiming for).

# 5. What is validation, and what’s a classic mistake you can make if you do it wrong? How did you validate your analysis?  [relevant rubric items: “discuss validation”, “validation strategy”]

Validation refers to how you confirm that your model is predictive of the outcome as desired - either through splitting your data into training/testing sets, or through a form of cross-validation. A classic validation mistake is not splitting your data and testing directly on the same data that you trained on - causing wildly inaccurate (overstated) results.

I validated through a split of train and test data, and then through a shuffle split (cross validation technique) in the final tester.py file to get to the final performance numbers.

# 6. Give at least 2 evaluation metrics and your average performance for each of them.  Explain an interpretation of your metrics that says something human-understandable about your algorithm’s performance. [relevant rubric item: “usage of evaluation metrics”]

The goal of this project was to lift recall and precision above a threshold (0.3), meaning that we wanted to have less than 70% false positives (precision) and less than 70% false negatives / misdiagnosed outtcomes (recall).

The final model that I produced had an average precision of 0.31015, and an average recall of 0.30100