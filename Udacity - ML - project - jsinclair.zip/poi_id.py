#!/usr/bin/python

import sys
import pickle
import json
import numpy as np
sys.path.append("../tools/")

from feature_format import featureFormat, targetFeatureSplit
from tester import dump_classifier_and_data
from sklearn.pipeline import Pipeline

from sklearn.decomposition import PCA
from sklearn.feature_selection import SelectFromModel
from sklearn.feature_selection import SelectKBest, chi2

from sklearn.model_selection import GridSearchCV

from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.neighbors import KNeighborsClassifier

from sklearn.cross_validation import StratifiedShuffleSplit
from sklearn.cross_validation import train_test_split

from sklearn.metrics import classification_report
from sklearn.metrics import recall_score
from sklearn.metrics import precision_score
from sklearn.metrics import f1_score


def find_users_with_no_data(scan_data):
    no_data_users = []
    for ppl, features in scan_data.items():
        non_NaN = False
        for feature, value in features.items():
            if feature != 'poi':
                if value != 'NaN':
                    non_NaN = True
                    break

        if not non_NaN:
            no_data_users.append(ppl)

    return no_data_users


def create_pct(partial, total):
    if partial == 'NaN':
        partial = 0
    if total == 'NaN':
        return 0

    return (float(partial) / float(total)) * 100.


def find_best_classifier(classifier_pipe, param_grid, all_features, all_labels):
    features_train, features_test, labels_train, labels_test = \
        train_test_split(all_features, all_labels, test_size=0.3, random_state=42)

    cv = StratifiedShuffleSplit(labels_train, 100, test_size=0.2, random_state=0)
    grid = GridSearchCV(classifier_pipe, param_grid=param_grid, cv=cv, scoring='f1', n_jobs=-1)
    grid.fit(features_train, labels_train)
    prediction = grid.predict(features_test)

    print('Precision:', precision_score(labels_test, prediction))
    print('Recall:', recall_score(labels_test, prediction))
    print('F1 Score:', f1_score(labels_test, prediction))

    print('Best score: %0.3f' % grid.best_score_)
    print('Best parameters set:')
    print(grid.best_estimator_.get_params())
    print(classification_report(labels_test, prediction))

    return grid.best_estimator_


# Task 1: Select what features you'll use.
# Pulling in all features, will select best features automatically in pipeline
features_list = [
    'poi', 'salary', 'bonus', 'deferred_income', 'exercised_stock_options',
    'deferral_payments', 'director_fees', 'expenses',
    'loan_advances', 'long_term_incentive', 'other', 'restricted_stock', 'restricted_stock_deferred',
    'shared_receipt_with_poi', 'total_payments', 'total_stock_value',
    'from_messages', 'to_messages', 'from_this_person_to_poi', 'from_poi_to_this_person',
    'from_poi_pct', 'to_poi_pct', 'shared_receipt_with_poi'
]
print(features_list[1:])

# Load the dictionary containing the dataset
with open("final_project_dataset.pkl", "r") as data_file:
    data_dict = pickle.load(data_file)

# Task 2: Remove outliers
# outlier exists for "TOTAL" row of data
# print(sorted(data_dict))
# print(find_users_with_no_data(data_dict))
outliers = ['TOTAL', 'LOCKHART EUGENE E', 'THE TRAVEL AGENCY IN THE PARK']
for outlier in outliers:
    data_dict.pop(outlier, 0)

# Task 3: Create new feature(s)
for person, features in data_dict.items():
    data_dict[person]['from_poi_pct'] = create_pct(features['from_poi_to_this_person'], features['to_messages'])
    data_dict[person]['to_poi_pct'] = create_pct(features['from_this_person_to_poi'], features['from_messages'])

# Store to my_dataset for easy export below.
my_dataset = data_dict

# Extract features and labels from dataset for local testing
data = featureFormat(my_dataset, features_list, sort_keys = True)
labels, features = targetFeatureSplit(data)

# Setup the classifier pipeline to filter data, identify primary components and maximise gain for f1 outcome
pipe = Pipeline([
    ('select_features', SelectKBest()),
    ('reduce_dim', PCA()),
    ('clf', DecisionTreeClassifier())
])

# Old param_grid used to narrow down which model was most effective
# DecisionTreeClassifier consistently was best, doubling down on that
forest_estimators = range(5, 50, 5)
tree_min_splits = range(2, 20, 2)
nearest_neighbours = [5, 10, 25, 50]
boost_estimators = [25, 50, 75, 100, 500]
n_components = [2, 4]
param_grid = [
    {
        'select_features__k': range(8, 10)
        , 'reduce_dim__n_components': n_components
        , 'clf': [GaussianNB()]
    },
    {
        'select_features__k': range(8, 10)
        , 'reduce_dim__n_components': n_components
        , 'clf': [DecisionTreeClassifier()]
        , 'clf__min_samples_split': tree_min_splits
    },
    {
        'select_features__k': range(8, 10)
        , 'reduce_dim__n_components': n_components
        , 'clf': [RandomForestClassifier()]
        , 'clf__n_estimators': forest_estimators
    },
    {
        'select_features__k': range(8, 10)
        , 'reduce_dim__n_components': n_components
        , 'clf': [AdaBoostClassifier()]
        , 'clf__n_estimators': boost_estimators
    },
    {
        'select_features__k': range(8, 10)
        , 'reduce_dim__n_components': n_components
        , 'clf': [KNeighborsClassifier()]
        , 'clf__n_neighbors': nearest_neighbours
    }
]

# Task 5: Tune your classifier to achieve better than .3 precision and recall using our testing script.
clf = find_best_classifier(pipe, param_grid, features, labels)

print(np.asarray(features_list[1:])[clf.named_steps.select_features.get_support()])

# Task 6: Dump your classifier, dataset, and features_list so anyone can check your results.
dump_classifier_and_data(clf, my_dataset, features_list)
